function PrivacyPolicy() {
  return (
    <div className="container">
      <h2>Privacy Policy</h2>
      <p>Your information is secure with us. We do not share user data with anyone except for fulfilling service requests as required by law.</p>
    </div>
  );
}
export default PrivacyPolicy;
