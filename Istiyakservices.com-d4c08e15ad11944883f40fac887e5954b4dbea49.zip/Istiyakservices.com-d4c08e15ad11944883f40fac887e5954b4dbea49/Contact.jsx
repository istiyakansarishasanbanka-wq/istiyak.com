function Contact() {
  return (
    <div className="container">
      <h2>Contact Us</h2>
      <p>Email: istiyakansari3110@gmail.com</p>
      <p>Location: India</p>
      <div>
        <a href="https://www.facebook.com/share/16Uxe2HUTz/" target="_blank">Facebook</a> |
        <a href="https://www.instagram.com/future_with_skills6" target="_blank">Instagram</a> |
        <a href="https://youtube.com/@istiyak7techz" target="_blank">YouTube</a>
      </div>
    </div>
  );
}
export default Contact;
